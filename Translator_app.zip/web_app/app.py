# app.py

from flask import Flask, render_template, request
import torch
from load_model import load_model
from model import AdditiveAttentionModel  # Import the model class
from translate import translate_sentence

app = Flask(__name__)

# Define device (GPU or CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the pre-trained model
model = AdditiveAttentionModel(input_dim=1000, output_dim=1000, hidden_dim=256, embedding_dim=256)
model = load_model(model, "models/Additive_Attention_model.pt", device)

# Define vocab dictionaries for SRC and TRG languages
SRC_LANGUAGE = 'en'
TRG_LANGUAGE = 'es'

src_vocab = torch.load('models/src_vocab.pt')
trg_vocab = torch.load('models/trg_vocab.pt')

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        input_text = request.form["sentence"]
        translation = translate_sentence(model, input_text, src_vocab, trg_vocab, device)
        return render_template("index.html", translation=translation)
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
