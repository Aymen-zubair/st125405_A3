# model.py

import torch
import torch.nn as nn
import torch.nn.functional as F

class AdditiveAttention(nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        self.W1 = nn.Linear(hidden_dim, hidden_dim)
        self.W2 = nn.Linear(hidden_dim, hidden_dim)
        self.v = nn.Linear(hidden_dim, 1, bias=False)

    def forward(self, hidden, encoder_outputs):
        if hidden.dim() == 2:
            hidden = hidden.unsqueeze(1)
        combined = torch.tanh(self.W1(encoder_outputs) + self.W2(hidden))
        attention_scores = self.v(combined).squeeze(2)  # [batch, src_len]
        return F.softmax(attention_scores, dim=1)

class AdditiveAttentionModel(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim, embedding_dim):
        super(AdditiveAttentionModel, self).__init__()

        # Encoder layers
        self.encoder = nn.Embedding(input_dim, embedding_dim)
        self.rnn = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)

        # Decoder layers
        self.decoder_embedding = nn.Embedding(output_dim, embedding_dim)
        self.decoder_rnn = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)

        # Additive attention mechanism
        self.attention = AdditiveAttention(hidden_dim)
        
        self.fc_out = nn.Linear(hidden_dim, output_dim)

    def forward(self, src, trg):
        # Encoder forward pass
        embedded_src = self.encoder(src)
        encoder_outputs, (hidden, cell) = self.rnn(embedded_src)

        # Decoder forward pass
        embedded_trg = self.decoder_embedding(trg)
        decoder_outputs, (hidden, cell) = self.decoder_rnn(embedded_trg, (hidden, cell))

        # Apply attention mechanism
        attention_weights = self.attention(hidden[-1], encoder_outputs)
        
        # Use attention weights to compute context vector
        context = torch.bmm(attention_weights.unsqueeze(1), encoder_outputs)

        # Combine context with decoder output and pass through the final linear layer
        combined = decoder_outputs + context
        output = self.fc_out(combined)

        return output, attention_weights
