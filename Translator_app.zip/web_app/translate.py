# translate.py

def translate_sentence(model, sentence, src_vocab, trg_vocab, device, max_len=50):
    # Tokenize the input sentence
    src_tokens = sentence.split()
    src_indices = [src_vocab[token] if token in src_vocab else src_vocab["<unk>"] for token in src_tokens]
    src_tensor = torch.tensor([src_indices], dtype=torch.long).to(device)

    # Encode
    with torch.no_grad():
        encoder_outputs, hidden = model.encoder(src_tensor)
        hidden = hidden[-1]  # Use last layer's hidden state

    # Decode
    generated_indices = []
    input_token = torch.tensor([trg_vocab["<sos>"]], dtype=torch.long).to(device)

    for _ in range(max_len):
        with torch.no_grad():
            output, hidden = model.decoder(input_token, hidden, encoder_outputs)
        predicted_idx = output.argmax(dim=1).item()
        generated_indices.append(predicted_idx)
        if predicted_idx == trg_vocab["<eos>"]:
            break
        input_token = torch.tensor([predicted_idx], dtype=torch.long).to(device)

    # Convert indices to words using the fixed reverse vocab
    reverse_trg_vocab = {idx: word for idx, word in enumerate(trg_vocab.get_itos())}
    translated_tokens = [reverse_trg_vocab[idx] for idx in generated_indices]

    return " ".join(translated_tokens)
