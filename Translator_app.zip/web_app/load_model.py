# load_model.py

import torch

def load_model(model, model_path, device):
    model.load_state_dict(torch.load(model_path, map_location=device), strict=False)
    model.to(device)
    model.eval()  # Set to evaluation mode
    return model
